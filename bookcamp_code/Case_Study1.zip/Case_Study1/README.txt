= Case Study 1
Covers Chapters 1-4.

= Requirements
matplotlib
numpy

